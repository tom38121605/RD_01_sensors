 * V1.1: Modify the factory test mode code on 20190322
 * V1.2: Change to 4 steps factory selftest on 20190417
 * V1.3: Change to 3 steps factory selftest on 20190520
 * V1.4: Change the upper limit value of manual selftest on 20190613
 * V1.5: Update to 1 step factory selftest on 20190619